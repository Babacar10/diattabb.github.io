#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

char* ping = "ping";
char* pong = "pong";

int main(int argc, char** argv){
    if(argc > 1) {
        fprintf(2, "Usage: pingpong\n");
        exit(1);
    }

    
 int fd[2];
 pipe(fd);
 int fd1[2];
 pipe(fd1);
 int pid = fork();
 if(pid!=0){
     close(fd[0]);
     write(fd[1], ping, strlen(ping) + 1);
    // exit(0);
 }
 else{
     char message[100];
     read(fd[0], message, strlen(ping) + 1);
    int pid_t1 = getpid();
     printf("<%d>: received %s\n",pid_t1,message);
    write(fd1[1], pong, strlen(pong) + 1);
     exit(0);
 }
   int status;
    wait(&status);
    int pid_tt = getpid();
    char message[100];
    read(fd1[0], message, strlen(pong) + 1);
    printf("<%d>: received %s\n",pid_tt,message);
    exit(0);

//  snprintf(string, 100, "%d", fd[1]);
//  char flower_color[20];
//  flower_color[19] = "\0";
        
//  read(fd[0], flower_color, sizeof(flower_color));
//  sprintf(buffer, "Sniffed %s flower\n", flower_color);



 

}